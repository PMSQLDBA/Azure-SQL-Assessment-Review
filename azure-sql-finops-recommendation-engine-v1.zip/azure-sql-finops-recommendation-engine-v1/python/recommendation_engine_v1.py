import argparse, csv, json
from collections import Counter, defaultdict
from pathlib import Path

def norm(v): return (v or "").strip().rstrip("/").lower()
def num(row, key, default=None):
    v = row.get(key)
    if v in (None, ""): return default
    try: return float(v)
    except: return default

def txt(row, key, default=""):
    return (row.get(key) or default).strip()

def boolish(v):
    return str(v).strip().lower() in ("1","true","yes","y")

def recommendation_base(row, rule_id, rec_type, title, confidence, risk, priority, reason):
    current = num(row, "currentMonthlyCost")
    target = num(row, "projectedMonthlyCost")
    monthly = annual = pct = None
    if current is not None and target is not None and current > 0:
        monthly = round(current-target, 2)
        annual = round(monthly*12, 2)
        pct = round(monthly/current*100, 2)
    return {
      "recommendationId": f"{rule_id}:{norm(row.get('resourceId'))}",
      "ruleId": rule_id,
      "subscriptionId": row.get("subscriptionId",""),
      "resourceGroup": row.get("resourceGroup",""),
      "serverName": row.get("serverName",""),
      "databaseName": row.get("databaseName",""),
      "resourceId": row.get("resourceId",""),
      "currentSku": row.get("skuName",""),
      "recommendedSku": row.get("recommendedSku",""),
      "recommendationType": rec_type,
      "recommendation": title,
      "confidence": confidence,
      "risk": risk,
      "priority": priority,
      "reason": reason,
      "source": "CUSTOM",
      "currentMonthlyCost": current,
      "projectedMonthlyCost": target,
      "monthlySaving": monthly,
      "annualSaving": annual,
      "savingPct": pct,
      "owner": row.get("owner",""),
      "status": "Identified"
    }

def evaluate(rows, policy):
    recs = []
    server_counts = Counter((r.get("subscriptionId",""), r.get("serverName","")) for r in rows)
    server_avg = defaultdict(list)
    for r in rows:
        c = num(r, "cpu_percent_avg")
        if c is not None:
            server_avg[(r.get("subscriptionId",""), r.get("serverName",""))].append(c)

    for row in rows:
        days = num(row,"observationDays",0)
        cpu_avg = num(row,"cpu_percent_avg")
        cpu95 = num(row,"cpu_percent_p95")
        data95 = num(row,"physical_data_read_percent_p95")
        log95 = num(row,"log_write_percent_p95")
        conn = num(row,"avgConnections")
        idle_hours = num(row,"idleHoursPerDay")
        growth90 = num(row,"storageGrowthPct90d")
        topq = num(row,"topQueriesCpuSharePct")
        cost_growth = num(row,"costGrowthPct")
        tier = txt(row,"skuTier")
        stable = boolish(row.get("stable24x7"))
        ahb_eligible = boolish(row.get("ahbEligible"))
        ahb_enabled = boolish(row.get("ahbEnabled"))
        server_key = (row.get("subscriptionId",""), row.get("serverName",""))

        if days >= policy["observation_days_min"] and all(v is not None for v in [cpu95,data95,log95]):
            hi = policy["rightsizing"]["high_confidence"]
            med = policy["rightsizing"]["medium_confidence"]
            if cpu95 < hi["p95_cpu_max"] and data95 < hi["p95_data_io_max"] and log95 < hi["p95_log_io_max"]:
                recs.append(recommendation_base(row,"SQL-COST-001","RIGHTSIZE","Evaluate next smaller compute SKU","HIGH","MEDIUM","HIGH",
                    f"P95 CPU/Data IO/Log IO are {cpu95:.1f}%/{data95:.1f}%/{log95:.1f}% over {int(days)} days."))
            elif cpu95 < med["p95_cpu_max"] and data95 < med["p95_data_io_max"] and log95 < med["p95_log_io_max"]:
                recs.append(recommendation_base(row,"SQL-COST-001","RIGHTSIZE_REVIEW","Review for compute rightsizing","MEDIUM","MEDIUM","MEDIUM",
                    f"Moderate headroom observed with P95 CPU/Data IO/Log IO {cpu95:.1f}%/{data95:.1f}%/{log95:.1f}%."))

        idle = policy["idle_database"]
        if days >= policy["observation_days_min"] and None not in [cpu_avg,cpu95,conn]:
            if cpu_avg < idle["avg_cpu_max"] and cpu95 < idle["p95_cpu_max"] and conn <= idle["avg_connections_max"]:
                recs.append(recommendation_base(row,"SQL-COST-002","IDLE_DB","Review for retirement, lower SKU, or serverless","HIGH","HIGH","HIGH",
                    f"Very low activity: avg CPU {cpu_avg:.1f}%, P95 CPU {cpu95:.1f}%, avg connections {conn:.1f}. Validate owner/dependencies before action."))

        srv = policy["serverless"]
        if None not in [cpu_avg,idle_hours] and tier not in srv["exclude_tiers"]:
            if cpu_avg < srv["avg_cpu_max"] and idle_hours >= srv["idle_hours_per_day_min"]:
                recs.append(recommendation_base(row,"SQL-COST-003","SERVERLESS","Evaluate serverless compute","MEDIUM","MEDIUM","MEDIUM",
                    f"Low average CPU ({cpu_avg:.1f}%) with about {idle_hours:.1f} idle hours/day suggests intermittent usage."))

        ep = policy["elastic_pool"]
        avgs = server_avg.get(server_key,[])
        if server_counts[server_key] >= ep["min_databases_same_server"] and avgs:
            if sum(avgs)/len(avgs) < ep["avg_cpu_max"] and not txt(row,"elasticPoolId"):
                recs.append(recommendation_base(row,"SQL-COST-004","ELASTIC_POOL","Evaluate elastic pool consolidation","MEDIUM","MEDIUM","MEDIUM",
                    f"Server hosts {server_counts[server_key]} databases with low average utilization; validate non-overlapping peak patterns."))

        bc = policy["business_critical_review"]
        if tier.lower().replace(" ","") == "businesscritical" and all(v is not None for v in [cpu95,data95,log95]):
            if cpu95 < bc["p95_cpu_max"] and data95 < bc["p95_data_io_max"] and log95 < bc["p95_log_io_max"]:
                recs.append(recommendation_base(row,"SQL-COST-005","BC_REVIEW","Review whether Business Critical tier is still required","MEDIUM","HIGH","HIGH",
                    "Business Critical workload shows material performance headroom. Validate latency, HA, read-scale, and architecture requirements before considering General Purpose."))

        if stable and days >= policy["reservation"]["observation_days_min"]:
            recs.append(recommendation_base(row,"SQL-COST-006","RESERVATION","Evaluate Azure Reservation coverage","MEDIUM","LOW","MEDIUM",
                "Workload is marked stable and 24x7. Validate commitment horizon and reservation coverage with FinOps."))

        if ahb_eligible and not ahb_enabled:
            recs.append(recommendation_base(row,"SQL-COST-007","AHB","Validate and enable Azure Hybrid Benefit if licensing permits","HIGH","LOW","HIGH",
                "Workload is marked AHB-eligible but AHB is not enabled. Licensing team must confirm eligibility."))

        if growth90 is not None and growth90 > policy["storage"]["growth_pct_90d_warn"]:
            recs.append(recommendation_base(row,"SQL-COST-008","STORAGE","Investigate storage growth and retention","MEDIUM","LOW","MEDIUM",
                f"Storage grew {growth90:.1f}% over 90 days. Review retention, large tables, unused indexes, audit/staging data."))

        if topq is not None and topq >= policy["query_cost"]["top_queries_cpu_share_pct_min"]:
            recs.append(recommendation_base(row,"SQL-COST-009","QUERY_COST","Tune high-cost queries before scaling compute","HIGH","LOW","HIGH",
                f"Top queries account for {topq:.1f}% of CPU. Query tuning may remove the need for higher compute."))

        if cost_growth is not None and cost_growth >= policy["cost_spike"]["pct_increase_min"]:
            recs.append(recommendation_base(row,"SQL-COST-010","COST_SPIKE","Investigate SQL cost increase","HIGH","LOW","HIGH",
                f"SQL cost increased {cost_growth:.1f}% versus the comparison period."))

        advisor_text = txt(row,"advisorCostRecommendation")
        advisor_count = num(row,"advisorCostRecommendationCount",0) or 0
        if advisor_text or advisor_count > 0:
            r = recommendation_base(row,"AZURE-ADVISOR","ADVISOR","Review Azure Advisor cost recommendation","HIGH","LOW","HIGH",
                advisor_text or f"{int(advisor_count)} Azure Advisor cost recommendation(s) found.")
            r["source"] = "AZURE_ADVISOR"
            recs.append(r)

    order = {"HIGH":3,"MEDIUM":2,"LOW":1}
    recs.sort(key=lambda x: (order.get(x["priority"],0), x["annualSaving"] or 0), reverse=True)
    return recs

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--input", required=True)
    p.add_argument("--policy", required=True)
    p.add_argument("--output", required=True)
    args = p.parse_args()
    policy = json.loads(Path(args.policy).read_text())
    with open(args.input, newline="", encoding="utf-8-sig") as fh:
        rows = list(csv.DictReader(fh))
    recs = evaluate(rows, policy)
    fields = ["recommendationId","ruleId","subscriptionId","resourceGroup","serverName","databaseName","resourceId",
              "currentSku","recommendedSku","recommendationType","recommendation","confidence","risk","priority","reason",
              "source","currentMonthlyCost","projectedMonthlyCost","monthlySaving","annualSaving","savingPct","owner","status"]
    with open(args.output,"w",newline="",encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=fields)
        w.writeheader(); w.writerows(recs)
    print(f"Wrote {len(recs)} recommendations to {args.output}")

if __name__ == "__main__": main()