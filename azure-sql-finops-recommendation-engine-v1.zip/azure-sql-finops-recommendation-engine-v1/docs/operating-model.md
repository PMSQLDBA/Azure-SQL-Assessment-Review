# Customer operating model

Recommended workflow:

Identified
-> Technical Review
-> Application Owner Review
-> Approved
-> Scheduled
-> Implemented
-> 24-hour validation
-> 7-day validation
-> 30-day billing validation
-> Savings Confirmed

## Dashboard measures

Track separately:
- Current monthly SQL spend
- Identified savings
- Approved savings
- Implemented savings
- Realized savings
- Savings realization %
- Recommendations by rule
- Recommendations by priority/risk
- Top 20 opportunities by annual savings
- Aging of unimplemented recommendations

## First production pilot

Start with one non-production subscription.
Manually validate the top 10 recommendations before enabling any remediation workflow.