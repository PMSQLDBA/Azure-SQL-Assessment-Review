# Azure SQL FinOps Recommendation Engine v1

This package converts the unified Azure SQL assessment dataset into prioritized customer recommendations.

## Implemented rules

- SQL-COST-001 — Compute rightsizing
- SQL-COST-002 — Idle database
- SQL-COST-003 — Serverless candidate
- SQL-COST-004 — Elastic Pool candidate
- SQL-COST-005 — Business Critical architecture review
- SQL-COST-006 — Azure Reservation candidate
- SQL-COST-007 — Azure Hybrid Benefit review
- SQL-COST-008 — Storage growth / retention
- SQL-COST-009 — Query-driven compute cost
- SQL-COST-010 — Cost spike
- AZURE-ADVISOR — Imported Advisor Cost recommendation

## Run

```bash
python python/recommendation_engine_v1.py \
  --input sample/unified_assessment.csv \
  --policy config/policy.json \
  --output sample/recommendations.csv
```

## Important design rules

- Thresholds are policy defaults, not Microsoft guarantees.
- Do not automatically resize production databases from these recommendations.
- Validate month-end/batch workload, HA/DR, latency and application SLA before a tier/SKU change.
- Serverless recommendations target intermittent, lower-average utilization workloads; validate resume latency and workload behavior.
- Elastic Pool recommendations require validation that databases can share capacity effectively and do not peak together.
- Azure Reservations and Azure Hybrid Benefit are commercial/licensing optimizations and should be validated by the customer's FinOps/licensing team.
- Use actual or amortized cost consistently for the customer's reporting standard.