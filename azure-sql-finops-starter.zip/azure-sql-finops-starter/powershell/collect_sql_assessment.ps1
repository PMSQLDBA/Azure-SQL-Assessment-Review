param(
    [int]$LookbackDays = 30,
    [string]$OutputPath = "./sql_assessment_raw.csv"
)

$ErrorActionPreference = "Stop"

Import-Module Az.Accounts
Import-Module Az.ResourceGraph
Import-Module Az.Monitor

$endTime = Get-Date
$startTime = $endTime.AddDays(-1 * $LookbackDays)

$query = @"
Resources
| where type =~ 'microsoft.sql/servers/databases'
| where name !~ 'master'
| extend
    serverName = tostring(split(id, '/')[8]),
    skuName = tostring(sku.name),
    skuTier = tostring(sku.tier),
    skuCapacity = toint(sku.capacity),
    elasticPoolId = tostring(properties.elasticPoolId)
| project
    subscriptionId,
    resourceGroup,
    serverName,
    databaseName = name,
    location,
    skuName,
    skuTier,
    skuCapacity,
    elasticPoolId,
    resourceId = id
"@

Write-Host "Discovering Azure SQL databases..."
$dbs = Search-AzGraph -Query $query -First 5000

if (-not $dbs) {
    Write-Warning "No Azure SQL databases found."
    return
}

$metricNames = @(
    "cpu_percent",
    "physical_data_read_percent",
    "log_write_percent",
    "sessions_percent",
    "workers_percent",
    "storage_percent"
)

$rows = @()

foreach ($db in $dbs) {
    Write-Host "Collecting metrics for $($db.databaseName)..."

    $record = [ordered]@{
        subscriptionId = $db.subscriptionId
        resourceGroup = $db.resourceGroup
        serverName = $db.serverName
        databaseName = $db.databaseName
        resourceId = $db.resourceId
        location = $db.location
        skuName = $db.skuName
        skuTier = $db.skuTier
        skuCapacity = $db.skuCapacity
        elasticPoolId = $db.elasticPoolId
        observationDays = $LookbackDays
    }

    foreach ($metric in $metricNames) {
        try {
            $m = Get-AzMetric `
                -ResourceId $db.resourceId `
                -MetricName $metric `
                -StartTime $startTime `
                -EndTime $endTime `
                -TimeGrain 01:00:00 `
                -AggregationType Average,Maximum

            $values = @()
            foreach ($series in $m.Data) {
                foreach ($point in $series.Data) {
                    if ($null -ne $point.Average) {
                        $values += [double]$point.Average
                    }
                }
            }

            if ($values.Count -gt 0) {
                $sorted = $values | Sort-Object
                $idx = [math]::Min(
                    $sorted.Count - 1,
                    [math]::Ceiling(0.95 * $sorted.Count) - 1
                )

                $record["${metric}_avg"] = [math]::Round(($values | Measure-Object -Average).Average, 2)
                $record["${metric}_p95"] = [math]::Round($sorted[$idx], 2)
                $record["${metric}_max"] = [math]::Round(($values | Measure-Object -Maximum).Maximum, 2)
            }
            else {
                $record["${metric}_avg"] = $null
                $record["${metric}_p95"] = $null
                $record["${metric}_max"] = $null
            }
        }
        catch {
            Write-Warning "Metric '$metric' failed for $($db.databaseName): $($_.Exception.Message)"
            $record["${metric}_avg"] = $null
            $record["${metric}_p95"] = $null
            $record["${metric}_max"] = $null
        }
    }

    # Cost fields are intentionally left blank here.
    # Join them from Azure Cost Management Export using resourceId.
    $record["currentMonthlyCost"] = $null
    $record["projectedMonthlyCost"] = $null
    $record["avgConnections"] = $null
    $record["storageGrowthPct90d"] = $null

    $rows += [pscustomobject]$record
}

$rows | Export-Csv -Path $OutputPath -NoTypeInformation
Write-Host "Assessment data written to $OutputPath"