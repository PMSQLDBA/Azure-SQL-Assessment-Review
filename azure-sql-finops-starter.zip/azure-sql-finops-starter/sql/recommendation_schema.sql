CREATE TABLE dbo.SqlCostRecommendations
(
    RecommendationId       nvarchar(1000) NOT NULL PRIMARY KEY,
    RuleId                  varchar(50) NOT NULL,
    SubscriptionId          varchar(100) NULL,
    ResourceGroup           nvarchar(256) NULL,
    ServerName              nvarchar(256) NULL,
    DatabaseName            nvarchar(256) NULL,
    ResourceId              nvarchar(1000) NOT NULL,

    CurrentSku              varchar(100) NULL,
    RecommendedSku          varchar(100) NULL,

    AvgCpu                  decimal(6,2) NULL,
    P95Cpu                  decimal(6,2) NULL,
    P95DataIo               decimal(6,2) NULL,
    P95LogIo                decimal(6,2) NULL,

    CurrentMonthlyCost      decimal(18,2) NULL,
    ProjectedMonthlyCost    decimal(18,2) NULL,
    MonthlySaving           decimal(18,2) NULL,
    AnnualSaving            decimal(18,2) NULL,
    SavingPct               decimal(8,2) NULL,

    RecommendationType      varchar(100) NOT NULL,
    RecommendationText      nvarchar(2000) NULL,
    Confidence              varchar(20) NULL,
    Risk                    varchar(20) NULL,

    Status                  varchar(30) NOT NULL DEFAULT ('Identified'),
    Owner                   nvarchar(200) NULL,
    ChangeTicket            nvarchar(100) NULL,

    IdentifiedDate          datetime2 NOT NULL DEFAULT (sysutcdatetime()),
    ApprovedDate            datetime2 NULL,
    ImplementedDate         datetime2 NULL,
    ValidationDate          datetime2 NULL,

    ActualMonthlySaving     decimal(18,2) NULL,
    Notes                   nvarchar(max) NULL
);

CREATE INDEX IX_SqlCostRecommendations_Status
    ON dbo.SqlCostRecommendations(Status);

CREATE INDEX IX_SqlCostRecommendations_ResourceId
    ON dbo.SqlCostRecommendations(ResourceId);