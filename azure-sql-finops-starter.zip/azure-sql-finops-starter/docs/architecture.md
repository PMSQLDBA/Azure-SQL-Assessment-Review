# Architecture and rollout

## 1. Data sources

### Azure Resource Graph
Use for resource inventory and configuration. Do not treat Resource Graph as a performance telemetry source.

### Azure Monitor
Collect at least:
- CPU percent
- Data IO / physical data read percent
- Log write percent
- Sessions percent
- Workers percent
- Storage percent

Use hourly aggregation for long lookback windows, then calculate average, maximum and P95.

### Azure Cost Management
Use recurring Cost Management Exports as the billing feed. Join cost rows to resources using resource IDs whenever possible. Prefer actual or amortized cost according to the customer's FinOps reporting standard.

### Azure Advisor
Import Advisor recommendations into the same repository. Keep Advisor findings distinct from custom SQL rules so the dashboard can show the source.

## 2. Core custom rules

- SQL-COST-001: Compute rightsizing
- SQL-COST-002: Idle / low-activity database
- SQL-COST-003: Serverless candidate
- SQL-COST-004: Elastic Pool candidate
- SQL-COST-005: Business Critical architecture review
- SQL-COST-006: Reservation candidate
- SQL-COST-007: Azure Hybrid Benefit review
- SQL-COST-008: Storage growth / retention
- SQL-COST-009: Query-driven compute waste
- SQL-COST-010: Cost spike / anomaly

## 3. Approval model

Recommended statuses:

Identified -> Technical Review -> Owner Review -> Approved -> Scheduled ->
Implemented -> Validation -> Savings Confirmed

Alternative terminal states:
Rejected / Deferred / Exception

Do not automatically resize production databases based only on low utilization.

## 4. Production guardrails

Before implementing a resize:
- Check month-end / quarter-end / batch-processing windows.
- Confirm application owner and SLA.
- Validate HA/DR and zone redundancy requirements.
- Capture current SKU and rollback SKU.
- Confirm maintenance/change window.

After implementing:
- Monitor CPU, IO, sessions/workers and application latency.
- Compare with baseline after 24 hours, 7 days and 30 days.
- Record realized cost reduction from actual billing.

## 5. Suggested Azure deployment

Small/medium estate:
- Azure Function or Automation Account
- Storage Account
- Azure SQL Database for recommendation state
- Logic App for approvals/notifications
- Power BI or Azure Workbook

Large enterprise:
- Azure Data Lake Storage
- Data Factory / Fabric / Synapse for cost ingestion
- Function Apps for recommendation logic
- Central SQL/Fabric warehouse
- Power BI
- ServiceNow/Jira integration
- Azure DevOps/GitHub Actions remediation pipeline

## 6. Security

Use managed identities wherever possible. Separate:
1. Read-only assessment identity.
2. Remediation identity with narrowly scoped SQL write permissions.

Keep remediation disabled until approval workflow and rollback are validated.