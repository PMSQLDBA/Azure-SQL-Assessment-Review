import argparse
import csv
import json
from pathlib import Path


def f(row, key, default=None):
    value = row.get(key)
    if value in (None, ""):
        return default
    try:
        return float(value)
    except ValueError:
        return default


def add_rec(recs, row, rule_id, rec_type, title, confidence, risk, reason,
            current_cost=None, projected_cost=None):
    monthly_saving = None
    annual_saving = None
    saving_pct = None

    if current_cost is not None and projected_cost is not None and current_cost > 0:
        monthly_saving = round(current_cost - projected_cost, 2)
        annual_saving = round(monthly_saving * 12, 2)
        saving_pct = round((monthly_saving / current_cost) * 100, 2)

    recs.append({
        "recommendationId": f"{rule_id}:{row.get('resourceId', row.get('databaseName', 'unknown'))}",
        "ruleId": rule_id,
        "subscriptionId": row.get("subscriptionId"),
        "resourceGroup": row.get("resourceGroup"),
        "serverName": row.get("serverName"),
        "databaseName": row.get("databaseName"),
        "resourceId": row.get("resourceId"),
        "currentSku": row.get("skuName"),
        "recommendationType": rec_type,
        "recommendation": title,
        "confidence": confidence,
        "risk": risk,
        "reason": reason,
        "currentMonthlyCost": current_cost,
        "projectedMonthlyCost": projected_cost,
        "monthlySaving": monthly_saving,
        "annualSaving": annual_saving,
        "savingPct": saving_pct,
        "status": "Identified"
    })


def evaluate(row, policy):
    recs = []

    days = f(row, "observationDays", 0)
    cpu_avg = f(row, "cpu_percent_avg")
    cpu_p95 = f(row, "cpu_percent_p95")
    data_p95 = f(row, "physical_data_read_percent_p95")
    log_p95 = f(row, "log_write_percent_p95")
    avg_conn = f(row, "avgConnections")
    storage_growth = f(row, "storageGrowthPct90d")
    current_cost = f(row, "currentMonthlyCost")
    projected_cost = f(row, "projectedMonthlyCost")

    if days >= policy["observation_days_min"]:
        strong = policy["strong_rightsize"]
        review = policy["review_rightsize"]

        if all(v is not None for v in [cpu_p95, data_p95, log_p95]):
            if (
                cpu_p95 < strong["p95_cpu_max"]
                and data_p95 < strong["p95_data_io_max"]
                and log_p95 < strong["p95_log_io_max"]
            ):
                add_rec(
                    recs, row, "SQL-COST-001", "RIGHTSIZE",
                    "Evaluate next smaller compute SKU",
                    "HIGH", "MEDIUM",
                    f"P95 CPU/Data IO/Log IO are {cpu_p95:.1f}%/{data_p95:.1f}%/{log_p95:.1f}% "
                    f"over {int(days)} days.",
                    current_cost, projected_cost
                )
            elif (
                cpu_p95 < review["p95_cpu_max"]
                and data_p95 < review["p95_data_io_max"]
                and log_p95 < review["p95_log_io_max"]
            ):
                add_rec(
                    recs, row, "SQL-COST-001", "RIGHTSIZE_REVIEW",
                    "Review for compute rightsizing",
                    "MEDIUM", "MEDIUM",
                    f"Moderate headroom observed: P95 CPU/Data IO/Log IO "
                    f"{cpu_p95:.1f}%/{data_p95:.1f}%/{log_p95:.1f}%.",
                    current_cost, projected_cost
                )

        idle = policy["idle"]
        if (
            cpu_avg is not None and cpu_p95 is not None and avg_conn is not None
            and cpu_avg < idle["avg_cpu_max"]
            and cpu_p95 < idle["p95_cpu_max"]
            and avg_conn <= idle["avg_connections_max"]
        ):
            add_rec(
                recs, row, "SQL-COST-002", "IDLE_DB",
                "Review database for retirement, serverless or lower SKU",
                "HIGH", "HIGH",
                f"Average CPU {cpu_avg:.1f}%, P95 CPU {cpu_p95:.1f}%, "
                f"average connections {avg_conn:.1f}. Validate ownership and dependencies."
            )

    if storage_growth is not None and storage_growth > policy["storage_growth_alert_pct_90d"]:
        add_rec(
            recs, row, "SQL-COST-008", "STORAGE_GROWTH",
            "Investigate storage growth and retention",
            "MEDIUM", "LOW",
            f"Storage increased {storage_growth:.1f}% over 90 days."
        )

    return recs


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True)
    parser.add_argument("--policy", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()

    policy = json.loads(Path(args.policy).read_text())

    with open(args.input, newline="", encoding="utf-8-sig") as fh:
        rows = list(csv.DictReader(fh))

    recommendations = []
    for row in rows:
        recommendations.extend(evaluate(row, policy))

    fields = [
        "recommendationId","ruleId","subscriptionId","resourceGroup","serverName",
        "databaseName","resourceId","currentSku","recommendationType","recommendation",
        "confidence","risk","reason","currentMonthlyCost","projectedMonthlyCost",
        "monthlySaving","annualSaving","savingPct","status"
    ]

    with open(args.output, "w", newline="", encoding="utf-8") as fh:
        writer = csv.DictWriter(fh, fieldnames=fields)
        writer.writeheader()
        writer.writerows(recommendations)

    print(f"Wrote {len(recommendations)} recommendations to {args.output}")


if __name__ == "__main__":
    main()