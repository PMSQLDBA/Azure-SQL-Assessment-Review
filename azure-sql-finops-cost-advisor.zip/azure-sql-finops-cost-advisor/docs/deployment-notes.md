# Deployment notes

## Cost ingestion

Recommended production pattern:

Cost Management scheduled Export
-> Storage Account / ADLS
-> Event or daily timer
-> Function reads new partition
-> normalize resourceId
-> aggregate by desired reporting period
-> write SqlAssessmentSnapshot

Use one customer-agreed cost basis consistently:
- Actual cost for invoice-aligned reporting.
- Amortized cost for FinOps reporting that spreads reservation purchases across usage.

## Advisor ingestion

The collector uses:
`GET /subscriptions/{subscriptionId}/providers/Microsoft.Advisor/recommendations?api-version=2025-01-01`

Filter to Cost-category recommendations either server-side when appropriate or client-side as implemented here.

Advisor returns cached recommendations. If a customer requires freshly recomputed recommendations, use the Advisor generate-recommendations workflow separately and wait for completion before listing cached results.

## Resource matching

Use full Azure resource ID as the canonical key.

Do not join only on:
- database name
- server name
- resource group

Those values are not globally unique.

## Permissions

Assessment identity:
- Reader or equivalent inventory access
- Monitoring Reader
- Cost Management Reader / access appropriate to export scope
- Advisor read access

Remediation identity:
- separate identity
- disabled from the assessment Function
- narrowly scoped write permissions
- human approval before production changes

## Production hardening

Before production:
- Read cost files directly from Blob/ADLS with Managed Identity.
- Handle compressed/parquet/partitioned exports where used.
- Persist ingestion watermark so files are not double counted.
- Add retry/backoff for ARM throttling.
- Log source file, export run ID and Advisor collection timestamp.
- Keep raw source files for audit/reconciliation.
- Add currency consistency validation.
- Add unit tests for export schemas used by the customer's billing agreement.