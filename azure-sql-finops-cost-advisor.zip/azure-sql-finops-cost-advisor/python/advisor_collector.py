import argparse
import json
import requests
from azure.identity import DefaultAzureCredential


API_VERSION = "2025-01-01"
ARM_SCOPE = "https://management.azure.com/.default"


def get_token():
    credential = DefaultAzureCredential()
    return credential.get_token(ARM_SCOPE).token


def collect_subscription(subscription_id, token):
    url = (
        f"https://management.azure.com/subscriptions/{subscription_id}"
        f"/providers/Microsoft.Advisor/recommendations"
        f"?api-version={API_VERSION}"
    )

    headers = {"Authorization": f"Bearer {token}"}
    items = []

    while url:
        response = requests.get(url, headers=headers, timeout=60)
        response.raise_for_status()
        payload = response.json()

        for item in payload.get("value", []):
            props = item.get("properties", {})
            category = props.get("category")
            if str(category).lower() == "cost":
                items.append(item)

        url = payload.get("nextLink")

    return items


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--subscriptions", required=True,
                   help="Comma-separated subscription IDs")
    p.add_argument("--output", required=True)
    args = p.parse_args()

    subscriptions = [s.strip() for s in args.subscriptions.split(",") if s.strip()]
    token = get_token()

    result = {
        "apiVersion": API_VERSION,
        "subscriptions": subscriptions,
        "recommendations": []
    }

    for sub in subscriptions:
        print(f"Collecting Advisor Cost recommendations for {sub}...")
        result["recommendations"].extend(collect_subscription(sub, token))

    with open(args.output, "w", encoding="utf-8") as fh:
        json.dump(result, fh, indent=2)

    print(f"Wrote {len(result['recommendations'])} Advisor cost recommendations to {args.output}")


if __name__ == "__main__":
    main()