import argparse
import csv
import json


def norm(value):
    return (value or "").strip().rstrip("/").lower()


def load_cost(path):
    data = {}
    with open(path, newline="", encoding="utf-8-sig") as fh:
        for row in csv.DictReader(fh):
            data[norm(row.get("resourceId"))] = row
    return data


def advisor_resource_id(item):
    props = item.get("properties", {})

    # Common Advisor payload shapes may carry resource metadata in different places.
    candidates = [
        item.get("resourceId"),
        props.get("resourceId"),
        props.get("resourceMetadata", {}).get("resourceId"),
        props.get("impactedValue")
    ]

    for value in candidates:
        if isinstance(value, str) and value.startswith("/subscriptions/"):
            return norm(value)

    return ""


def advisor_text(item):
    props = item.get("properties", {})
    short = props.get("shortDescription") or {}
    problem = short.get("problem") or ""
    solution = short.get("solution") or ""
    if problem and solution:
        return f"{problem} | {solution}"
    return problem or solution or props.get("description", "") or ""


def load_advisor(path):
    with open(path, encoding="utf-8") as fh:
        payload = json.load(fh)

    by_resource = {}
    for item in payload.get("recommendations", []):
        rid = advisor_resource_id(item)
        if not rid:
            continue
        by_resource.setdefault(rid, []).append(item)
    return by_resource


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--metrics", required=True)
    p.add_argument("--cost", required=True)
    p.add_argument("--advisor", required=True)
    p.add_argument("--output", required=True)
    args = p.parse_args()

    costs = load_cost(args.cost)
    advisor = load_advisor(args.advisor)

    with open(args.metrics, newline="", encoding="utf-8-sig") as fh:
        rows = list(csv.DictReader(fh))

    base_fields = list(rows[0].keys()) if rows else []
    extra = [
        "costMode", "currentPeriodCost", "currency",
        "advisorCostRecommendationCount", "advisorCostRecommendation"
    ]

    with open(args.output, "w", newline="", encoding="utf-8") as fh:
        writer = csv.DictWriter(fh, fieldnames=base_fields + extra)
        writer.writeheader()

        for row in rows:
            rid = norm(row.get("resourceId"))
            c = costs.get(rid, {})
            a = advisor.get(rid, [])

            output = dict(row)
            output.update({
                "costMode": c.get("costMode", ""),
                "currentPeriodCost": c.get("cost", ""),
                "currency": c.get("currency", ""),
                "advisorCostRecommendationCount": len(a),
                "advisorCostRecommendation": " || ".join(
                    filter(None, [advisor_text(x) for x in a])
                )
            })
            writer.writerow(output)

    print(f"Wrote joined assessment data for {len(rows)} resources to {args.output}")


if __name__ == "__main__":
    main()