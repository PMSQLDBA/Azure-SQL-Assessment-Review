import argparse
import csv
from collections import defaultdict
from pathlib import Path


RESOURCE_ID_CANDIDATES = [
    "ResourceId", "ResourceID", "resourceId", "resourceid",
    "InstanceId", "instanceId"
]

ACTUAL_COST_CANDIDATES = [
    "CostInBillingCurrency", "costInBillingCurrency",
    "Cost", "cost", "ActualCost", "actualCost"
]

AMORTIZED_COST_CANDIDATES = [
    "CostInBillingCurrency", "costInBillingCurrency",
    "AmortizedCost", "amortizedCost", "Cost", "cost"
]

CURRENCY_CANDIDATES = [
    "BillingCurrencyCode", "billingCurrencyCode",
    "Currency", "currency"
]


def normalize_resource_id(value: str) -> str:
    return (value or "").strip().rstrip("/").lower()


def get_first(row, candidates):
    # Exact first
    for c in candidates:
        if c in row and row[c] not in (None, ""):
            return row[c]
    # Case-insensitive
    lower = {k.lower(): k for k in row}
    for c in candidates:
        key = lower.get(c.lower())
        if key and row[key] not in (None, ""):
            return row[key]
    return None


def parse_number(value):
    if value in (None, ""):
        return 0.0
    return float(str(value).replace(",", ""))


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--input", required=True)
    p.add_argument("--output", required=True)
    p.add_argument("--cost-mode", choices=["actual", "amortized"], default="amortized")
    args = p.parse_args()

    totals = defaultdict(float)
    currency = {}
    row_count = defaultdict(int)

    with open(args.input, newline="", encoding="utf-8-sig") as fh:
        reader = csv.DictReader(fh)
        for row in reader:
            rid = normalize_resource_id(get_first(row, RESOURCE_ID_CANDIDATES))
            if not rid:
                continue

            candidates = ACTUAL_COST_CANDIDATES if args.cost_mode == "actual" else AMORTIZED_COST_CANDIDATES
            cost_value = get_first(row, candidates)

            try:
                cost = parse_number(cost_value)
            except ValueError:
                continue

            totals[rid] += cost
            row_count[rid] += 1

            cur = get_first(row, CURRENCY_CANDIDATES)
            if cur:
                currency[rid] = cur

    with open(args.output, "w", newline="", encoding="utf-8") as fh:
        fields = ["resourceId", "costMode", "cost", "currency", "sourceRows"]
        writer = csv.DictWriter(fh, fieldnames=fields)
        writer.writeheader()
        for rid in sorted(totals):
            writer.writerow({
                "resourceId": rid,
                "costMode": args.cost_mode,
                "cost": round(totals[rid], 6),
                "currency": currency.get(rid, ""),
                "sourceRows": row_count[rid]
            })

    print(f"Wrote {len(totals)} resource cost records to {args.output}")


if __name__ == "__main__":
    main()