# Azure SQL FinOps - Cost + Advisor Integration

This package adds the next working layer to the Azure SQL FinOps starter:

1. Read Cost Management export CSV files from local/staged storage.
2. Normalize Azure Resource IDs.
3. Aggregate Actual or Amortized cost by SQL database resource ID.
4. Collect Azure Advisor recommendations for one or more subscriptions.
5. Filter Advisor cost recommendations and match them to Azure SQL resources.
6. Join inventory + metrics + cost + Advisor into one assessment dataset.

## Files

- `python/cost_export_reader.py` - reads Cost Management export CSV files.
- `python/advisor_collector.py` - calls Azure Advisor REST API.
- `python/join_assessment.py` - joins metrics, cost and Advisor data by resource ID.
- `config/settings.json` - API versions and cost settings.
- `sample/metrics.csv` - sample SQL metrics/inventory.
- `sample/cost_export.csv` - simplified example Cost Management export.
- `sample/advisor.json` - example Advisor payload.
- `sample/assessment_output.csv` - generated example joined dataset.
- `sql/assessment_schema.sql` - optional normalized assessment table.
- `docs/deployment-notes.md` - Azure deployment and security notes.

## Authentication

`advisor_collector.py` uses Azure Identity `DefaultAzureCredential`.

For local testing:
- `az login`

For Azure Function / Automation:
- Enable Managed Identity.
- Grant read-only permissions required for Advisor and target subscriptions.

## Python dependencies

```bash
pip install azure-identity requests
```

## Step 1 - Read cost export

```bash
python python/cost_export_reader.py \
  --input sample/cost_export.csv \
  --output sample/cost_by_resource.csv \
  --cost-mode actual
```

Supported cost modes:
- `actual`
- `amortized`

The reader tries common Azure Cost Management column names case-insensitively.

## Step 2 - Collect Azure Advisor recommendations

```bash
python python/advisor_collector.py \
  --subscriptions <subscription-id-1>,<subscription-id-2> \
  --output advisor.json
```

Default API version:
- Azure Advisor `2025-01-01`

The collector keeps Cost-category recommendations and follows pagination.

## Step 3 - Join assessment data

```bash
python python/join_assessment.py \
  --metrics sample/metrics.csv \
  --cost sample/cost_by_resource.csv \
  --advisor sample/advisor.json \
  --output assessment_output.csv
```

## Join key

The primary join key is normalized Azure `resourceId`.

Normalization:
- trim whitespace
- lowercase
- remove trailing `/`

Do not rely on database name alone because the same name can exist in multiple subscriptions/resource groups/servers.

## Production recommendation

Use Cost Management Exports as the recurring billing feed, land them in a central Storage Account / ADLS container, then process new export partitions daily.

Keep:
- actual cost for invoice-oriented analysis
- amortized cost for reservation-aware FinOps analysis

Choose one as the customer standard and use it consistently in savings reporting.