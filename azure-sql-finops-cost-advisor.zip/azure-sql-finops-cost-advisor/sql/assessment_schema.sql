CREATE TABLE dbo.SqlAssessmentSnapshot
(
    SnapshotId                       bigint IDENTITY(1,1) PRIMARY KEY,
    SnapshotDateUtc                  datetime2 NOT NULL DEFAULT sysutcdatetime(),

    SubscriptionId                  varchar(100) NOT NULL,
    ResourceGroup                   nvarchar(256) NULL,
    ServerName                      nvarchar(256) NULL,
    DatabaseName                    nvarchar(256) NULL,
    ResourceId                      nvarchar(1000) NOT NULL,

    SkuName                         varchar(100) NULL,
    SkuTier                         varchar(100) NULL,
    SkuCapacity                     int NULL,

    ObservationDays                 int NULL,
    AvgCpuPercent                   decimal(8,2) NULL,
    P95CpuPercent                   decimal(8,2) NULL,
    P95DataIoPercent                decimal(8,2) NULL,
    P95LogIoPercent                 decimal(8,2) NULL,

    CostMode                        varchar(20) NULL,
    CurrentPeriodCost               decimal(18,4) NULL,
    Currency                        varchar(10) NULL,

    AdvisorCostRecommendationCount  int NOT NULL DEFAULT 0,
    AdvisorCostRecommendation       nvarchar(max) NULL
);

CREATE INDEX IX_SqlAssessmentSnapshot_ResourceId_Date
ON dbo.SqlAssessmentSnapshot(ResourceId, SnapshotDateUtc DESC);